import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  
  public isLoggedIn : boolean = false;

  constructor(public httpReq : HttpClient) { 
    
  }

  /////////////////////////
  displayMsg(type : string = '',message : string = '') {
    if(type == 'success'){
      console.log("success");
    }else if(type == 'warning'){
      console.log("warning");
    }else if(type == 'error'){
      console.log("error");
    }
  }
  apiCall(url : string,body : any,options :any = '') : Promise<any>{

    
    let postBody = body;
    let postRe = this.httpReq.post(url,postBody);

    // postRe.subscribe((response)=>{
    //   console.log(response);
    // });

    return postRe.toPromise()
    .then((res)=>{
      console.log('common service logged');
      if(res=="error"){
        throw Error;
      }
      return res;
    })
    .catch((error)=>{
        throw error;
    });
  }

  ////////signup

  signupapiCall(url : string,body : any,options :any = '') : Promise<any>{
    
    let signBody = body;
    console.log(url);

    let signReq = this.httpReq.post(url,{'data':signBody});
    return signReq.toPromise()
    .then((res)=>{
      console.log(res);
      console.log('common service logged');
      return res;
    })
    .catch((error)=>{
        throw error;
    });
  }

  profileFinder(url : string,body : any,options :any = '') : Promise<any>
  {  
    let signBody = body;
    let signReq = this.httpReq.post(url,signBody);

    return signReq.toPromise()
    .then((res)=>{
      console.log('common service logged');
      return res;
    })
    .catch((error)=>{
        throw error;
    });
  }
  //////////////////blog creator

  blogCreator(url : string,body : any,options :any = '') : Promise<any>{
    let blogBody = body;
    let blogReq = this.httpReq.post(url,blogBody);

    return blogReq.toPromise()
    .then((res)=>{
      console.log('common service logged of blog creator');
      return res;
    })
    .catch((error)=>{
        throw error;
    });
  }

  ////////////////your blog

  yourBlog(url : string,body : any,options :any = '') : Promise<any>{
    let blogBody = body;
    let blogReq = this.httpReq.post(url,{'data':blogBody});

    return blogReq.toPromise()
    .then((res)=>{
      console.log('common service logged of  your blog');
      return res;
    })
    .catch((error)=>{
        throw error;
    });
  }
  /////all Blog

  allBlog(url : string) : Promise<any>{
    
    let blogReq = this.httpReq.post(url,null);

     return blogReq.toPromise()
    .then((res)=>{
      console.log('common service logged of  All blog');
      return res;
    })
    .catch((error)=>{
        throw error;
    });
  }




}


