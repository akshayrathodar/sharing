import { FormControl, FormGroup, ValidatorFn, ValidationErrors, AbstractControl } from '@angular/forms';

export class CustomValidations {
    
    constructor() {}

    public comparisonValidator(form : FormGroup,field1 : string,field2 : string) : ValidatorFn{
        return (group: FormGroup): ValidationErrors => {
            const control1 = group.controls[field1];
            const control2 = group.controls[field2];

            if(control2.value != null && control2.value != undefined && control2.value != ''){
                if (control1.value !== control2.value) {
                    control2.setErrors({notEquivalent: true});
                } else {
                    control2.setErrors(null);
                }
            }
            return;
        };
    }
}
