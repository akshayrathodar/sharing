import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { FormBuilder, FormGroup,Validators } from '@angular/forms';
import { CommonService } from '../services/common.service';



import { from } from 'rxjs';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public frmLogin : FormGroup;
  public isFormSubmit : boolean = false;

  constructor(public commonSer:CommonService,public formBl : FormBuilder,public router : Router) { 

    this.frmLogin = this.formBl.group({
      'email' : ['',[Validators.required,Validators.minLength(6)]],
      'password' : ['',Validators.required]
    });

  }

  ngOnInit() {
  

  }

  loginSubmit(){

    this.isFormSubmit = true;

    if(!(this.frmLogin.invalid)){
      let email = this.frmLogin.value.email;
      let password = this.frmLogin.value.password;

      let url = 'http://192.168.100.246:3000/login';
      

      let body = new FormData();
      body.append("action","login"); 
      body.append("email",email);
      body.append("password",password);

      let returnOutput = this.commonSer.apiCall(url,body);

      returnOutput.then((res)=>{
         console.log(res);
         if(res != null && res != undefined){
            
              this.commonSer.displayMsg('success',res.message);
              this.commonSer.isLoggedIn = true;
              console.log(res.token);
              if(res.token !== null && res.token !== undefined)
              {
                localStorage.setItem('token',res.token);
                console.log('logged in value',this.commonSer.isLoggedIn);
                this.commonSer.isLoggedIn = true;
                console.log('logged in value',this.commonSer.isLoggedIn);
                this.router.navigate(['/profile']);
                
              }
              else if(res.message == 'empty')
              {
                alert("No User Found");
              }
              else{
                alert(" Please Try Again ");
              }
            //this.router.navigate(['profile/','1']);     
          }
          else{
            alert("Didn't Get Response");
          }
        })
      .catch((error)=>{
        console.log(error);
      });
      
   
  

  }
}


}
