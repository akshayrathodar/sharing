import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from '../services/common.service';
import { FormBuilder, FormGroup , Validators } from '@angular/forms';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  public frmgroup : FormGroup;
  constructor(public router:Router,public commonSer:CommonService,public builder:FormBuilder) {  }
  public firstname :any;
  public lastname : any;
  public email:any;
  public mobile:any;
  public yb:any = false;
  public isFormSubmit : boolean = false;
  ngOnInit() {
    
    if(localStorage.getItem('token')!=null && localStorage.getItem('token')!=undefined && localStorage.getItem('token')!='')
    {  
      this.commonSer.isLoggedIn = true;
      this.frmgroup = this.builder.group({
        blogtitle:[""],
        blogdesc:[""]
      })



      var token = localStorage.getItem('token');
      let url = 'http://192.168.100.246:3000/profiler';
      

      let body = new FormData();
      body.append("token",token);
      let retuprof = this.commonSer.profileFinder(url,body);

      retuprof.then((res)=>{
         
         if(res != null && res != undefined){
            
              this.commonSer.displayMsg('success',res.message);
              this.commonSer.isLoggedIn = true;

              this.firstname = res.firstname;
              this.lastname = res.lastname;
              this.email = res.email;
              this.mobile = res.mobile;
              
          }
          else{
            alert("Didn't Get Response");
            this.router.navigate['/login'];
            
          }
        })
      .catch((error)=>{
        console.log(error);
      });

      

    }
    else{ 
      this.router.navigate(['/login']);
    }

  } ///// init close

  //enterblog
  blogCreate(){
    this.isFormSubmit = true;
    let tit = this.frmgroup.value.blogtitle;
    let desc = this.frmgroup.value.blogdesc;

    let url = 'http://192.168.100.246:3000/createblog';
      

    let body = new FormData();
    body.append("title",tit);
    body.append("desc",desc);
    body.append("token",localStorage.getItem('token'));
    let returnblogstat = this.commonSer.blogCreator(url,body);
    returnblogstat.then(res=>{
      if(res == "true"){
        alert("Blog Added Successfully");
      }
    })
    .catch(err=>{
      console.log(err);
    });
  }

  displayblog(){
    let body = new FormData();
    body.append("token",localStorage.getItem('token'));
    let url = 'http://192.168.100.246:3000/yourblog';
    let returnblogstat = this.commonSer.yourBlog(url,body);
    returnblogstat.then(res=>{
      this.yb = res;
      console.log(res);
    })
    .catch(err=>{
      console.log(err);
    });

  }

}
