import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup , Validators } from '@angular/forms';
import { CommonService } from '../services/common.service';
import { Router } from '@angular/router';
import { CustomValidations } from '../validators/custom-validator';
import { from } from 'rxjs';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  public signupForm : FormGroup;
  submitted = false;
  public firstname:any;
  public lastname:any;
  public mail:any;
  public mob:any;
  public pass:any;
  public cpass:any;
  public conval = new CustomValidations();
  constructor(private formBuilder: FormBuilder,public commonSer : CommonService,public router:Router) { 
    this.firstname=true;
    this.lastname=true;
    this.mail=true;
    this.mob=true;
    this.pass=true;
    this.cpass=true;
  }

  ngOnInit() {
    this.signupForm = this.formBuilder.group({
      fnm : ["",[Validators.required,Validators.minLength(4)]],
      lnm : ["",[Validators.required,Validators.minLength(4)]],
      mail: ['', [Validators.required,Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]],
      mob : ["",[Validators.required,Validators.minLength(10)]],
      pass : ["",[Validators.required,Validators.minLength(6)]],
      cpass : ["",Validators.required]

    });
    this.signupForm.setValidators(this.conval.comparisonValidator(this.signupForm,"pass","cpass"));
  }
 
  onSubmit() {
    this.submitted = true;
    if (this.signupForm.invalid) {
        return;
    }
    let firstname = this.signupForm.value.fnm;
    let lastname = this.signupForm.value.lnm;
    let mail = this.signupForm.value.mail;
    let mob = this.signupForm.value.mob;
    let cpass = this.signupForm.value.pass;

      let url="http://localhost/php/";
      let body = {
      "firstname":firstname,
      "lastname":lastname, 
      "email":mail,
      "mobile":mob,
      "password":cpass
      }
      let acknowledge = this.commonSer.signupapiCall(url,body);

      acknowledge.then((res)=>{
        if(res != null && res != undefined){
           
             this.commonSer.displayMsg('success',res.message);
             this.commonSer.isLoggedIn = true;
             if(res == "error")
             {
                alert("Error in sign up");
               //localStorage.setItem('token',res);
             }
             else{
               if(res == "username not avalible")
               {
                 alert("This Mobile number Or Email Already Registerd ");
               }
               else{
                console.log(res);
                localStorage.setItem('token',res);
                }
             }


           //this.router.navigate(['profile/','1']);     
         }
       })
     .catch((error)=>{
       alert("Error in Signup Please try Again");
       console.log(error);
     });
}

}
