import { Component, OnInit ,Input } from '@angular/core';

@Component({
  selector: 'app-errordisplay',
  templateUrl: './errordisplay.component.html',
  styleUrls: ['./errordisplay.component.css']
})
export class ErrordisplayComponent implements OnInit {
  @Input('fnm') firstname:any;
  @Input('lnm') lastname:any;
  @Input('mail') mail:any;
  @Input('mob') mob:any;
  @Input('pass') pass:any;
  @Input('cpass') cpass:any;
  @Input('sf') signupForm:any; 
  constructor() { }

  ngOnInit() {
  }

}
